return {

  no_consumer = true,

  fields = {

    input_header_name = { type = "string", required = true },
    property_to_pick = { type = "string", required = true},
    output_header_name = { type = "string", required = true }

  }

}